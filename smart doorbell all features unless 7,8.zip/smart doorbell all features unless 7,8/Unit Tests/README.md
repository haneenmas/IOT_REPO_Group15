## This folder contains Valdation tests done to check sensors/hardware parts
