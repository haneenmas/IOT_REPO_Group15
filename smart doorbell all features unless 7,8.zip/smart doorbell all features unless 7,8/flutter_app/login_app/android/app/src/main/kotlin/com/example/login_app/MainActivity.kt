package com.example.login_app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

  private val methodChannelName = "doorbell/mic_stream"
  private val statusEventChannelName = "doorbell/mic_stream_events"
  private val pcmEventChannelName = "doorbell/mic_pcm"

  private val REQ_RECORD_AUDIO = 2001

  private var micStreamer: MicStreamer? = null

  // Permission flow
  private var pendingStart: Boolean = false
  private var pendingResult: MethodChannel.Result? = null

  // Sinks
  private var statusSink: EventChannel.EventSink? = null
  private var pcmSink: EventChannel.EventSink? = null

  override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
    super.configureFlutterEngine(flutterEngine)

    // Status events
    EventChannel(flutterEngine.dartExecutor.binaryMessenger, statusEventChannelName)
      .setStreamHandler(object : EventChannel.StreamHandler {
        override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
          statusSink = events
        }
        override fun onCancel(arguments: Any?) {
          statusSink = null
        }
      })

    // PCM events (ByteArray chunks)
    EventChannel(flutterEngine.dartExecutor.binaryMessenger, pcmEventChannelName)
      .setStreamHandler(object : EventChannel.StreamHandler {
        override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
          pcmSink = events
        }
        override fun onCancel(arguments: Any?) {
          pcmSink = null
        }
      })

    MethodChannel(flutterEngine.dartExecutor.binaryMessenger, methodChannelName)
      .setMethodCallHandler { call, result ->
        when (call.method) {
          "startMic" -> {
            startMicWithPermission(result)
          }
          "stopMic" -> {
            stopMic()
            result.success(true)
          }
          else -> result.notImplemented()
        }
      }
  }

  private fun startMicWithPermission(result: MethodChannel.Result) {
    val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    if (!granted) {
      pendingStart = true
      pendingResult = result
      try {
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), REQ_RECORD_AUDIO)
        statusSink?.success("permission_request")
      } catch (e: Exception) {
        result.error("PERMISSION_REQUEST_FAILED", e.toString(), null)
      }
      return
    }
    startMic(result)
  }

  private fun startMic(result: MethodChannel.Result) {
    try {
      if (micStreamer == null) {
        micStreamer = MicStreamer(
          onState = { s -> runOnUiThread { statusSink?.success(s) } },
          onError = { e -> runOnUiThread { statusSink?.success("error:$e") } },
          onPcm = { bytes ->
            // Send raw bytes to Dart (Uint8List)
            runOnUiThread { pcmSink?.success(bytes) }
          }
        )
      }
      micStreamer?.start()
      result.success(true)
    } catch (e: Exception) {
      statusSink?.success("error:${e}")
      result.error("START_FAILED", e.toString(), null)
    }
  }

  private fun stopMic() {
    try {
      micStreamer?.stop()
      statusSink?.success("stopped")
    } catch (_: Exception) {}
  }

  override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults)

    if (requestCode == REQ_RECORD_AUDIO) {
      val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
      val res = pendingResult
      pendingResult = null
      val shouldStart = pendingStart
      pendingStart = false

      if (!granted) {
        statusSink?.success("permission_denied")
        res?.success(false)
        return
      }

      statusSink?.success("permission_granted")
      if (shouldStart && res != null) startMic(res)
    }
  }

  override fun onDestroy() {
    stopMic()
    super.onDestroy()
  }
}
