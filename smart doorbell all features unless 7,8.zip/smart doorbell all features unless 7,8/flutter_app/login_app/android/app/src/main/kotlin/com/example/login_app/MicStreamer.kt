package com.example.login_app

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.util.concurrent.atomic.AtomicBoolean

class MicStreamer(
  private val onState: (String) -> Unit,
  private val onError: (String) -> Unit,
  private val onPcm: (ByteArray) -> Unit,
) {
  private val running = AtomicBoolean(false)

  private var audioRecord: AudioRecord? = null
  private var thread: Thread? = null

  fun start() {
    if (running.get()) {
      onState("already_running")
      return
    }
    running.set(true)
    onState("starting")

    // PCM16 mono 16kHz to match ESP
    val sampleRate = 16000
    val channelConfig = AudioFormat.CHANNEL_IN_MONO
    val audioFormat = AudioFormat.ENCODING_PCM_16BIT

    val minBuf = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
    if (minBuf == AudioRecord.ERROR || minBuf == AudioRecord.ERROR_BAD_VALUE) {
      onError("bad_buffer_size:$minBuf")
      stop()
      return
    }

    val bufSize = minBuf * 2
    val recorder = AudioRecord(
      MediaRecorder.AudioSource.VOICE_RECOGNITION,
      sampleRate,
      channelConfig,
      audioFormat,
      bufSize
    )
    audioRecord = recorder

    try {
      recorder.startRecording()
    } catch (se: SecurityException) {
      onError("no_record_permission")
      stop()
      return
    } catch (e: Exception) {
      onError("start_record_failed:${e.message}")
      stop()
      return
    }

    thread = Thread {
      try {
        onState("recording")
        val buffer = ByteArray(1024)
        while (running.get()) {
          val read = recorder.read(buffer, 0, buffer.size)
          if (read > 0) {
            if (read == buffer.size) {
              onPcm(buffer)
            } else {
              onPcm(buffer.copyOfRange(0, read))
            }
          }
        }
      } catch (e: Exception) {
        onError("record_loop_error:${e.message}")
      } finally {
        try { recorder.stop() } catch (_: Exception) {}
        try { recorder.release() } catch (_: Exception) {}
        audioRecord = null
        onState("recording_stopped")
        running.set(false)
      }
    }.also { it.name = "MicStreamerThread"; it.start() }
  }

  fun stop() {
    if (!running.getAndSet(false)) return
    try { audioRecord?.stop() } catch (_: Exception) {}
    try { audioRecord?.release() } catch (_: Exception) {}
    audioRecord = null
    try { thread?.interrupt() } catch (_: Exception) {}
    thread = null
    onState("stopped")
  }
}
